/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   skyscrapers.h                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lgeoffro <marvin@student.42.fr>            +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/21 22:30:45 by lgeoffro          #+#    #+#             */
/*   Updated: 2021/03/21 22:31:29 by lgeoffro         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_SKYSCRAPERS_H
# define FT_SKYSCRAPERS_H
# include <unistd.h>

void	ft_putstr(char *str);
void	ft_putchar(char c);

int		ft_init_grid(int *views);
int		ft_backtrack(int grid[4][4], int *input);
void	ft_display_grid(int grid[4][4]);
int		ft_check_grid(int grid[4][4], int *in_num);

#endif
